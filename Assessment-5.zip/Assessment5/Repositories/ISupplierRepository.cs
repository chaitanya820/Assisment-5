﻿using Assessment5.Entities;

namespace Assessment5.Repositories
{
    public interface ISupplierRepository
    {
        Task<List<Supplier>> GetAll();
        Task<Supplier> GetBySuplno(string suplno);
        Task Add(Supplier supplier);
        Task Update(Supplier supplier);
        Task Delete(string suplno);
    }
}
