﻿using Assessment5.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Assessment5.Repositories
{
    public class SupplierRepository:ISupplierRepository
    {
        private readonly PODbContext _context;
        public SupplierRepository(PODbContext context)
        {
            _context = context;
        }

        public async Task Add(Supplier supplier)
        {
            await _context.Suppliers.AddAsync(supplier);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string suplno)
        {
            var supplier=await _context.Suppliers.FindAsync(suplno);
            _context.Suppliers.Remove(supplier);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Supplier>> GetAll()
        {
            return await _context.Suppliers.ToListAsync();
        }

        public async Task<Supplier> GetBySuplno(string suplno)
        {
            return await _context.Suppliers.SingleOrDefaultAsync(s=>s.Suplno==suplno);
        }

        public async Task Update(Supplier supplier)
        {
            _context.Suppliers.Update(supplier);
            await _context.SaveChangesAsync();
        }
    }
}
