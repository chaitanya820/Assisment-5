﻿using Assessment5.Entities;

namespace Assessment5.Repositories
{
    public interface IItemRepository
    {
        Task<List<Item>> GetAll();
        Task<Item> GetByITCODE(string itcode);
        Task Add(Item item);
        Task Update(Item item);
        Task Delete(string itcode);
    }
}
