﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assessment5.Entities
{
    public class Supplier
    {
        [Key]
        [Column(TypeName = "char")]
        [StringLength(4)]
        public string Suplno {  get; set; }

        [Column(TypeName ="varchar")]
        [StringLength(15)]
        public string SupplName { get; set; }
        [Column(TypeName ="varchar")]
        [StringLength(40)]
        public string SupLAddr { get; set; }
    }
}
