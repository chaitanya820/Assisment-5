﻿using Assessment5.DTOS;
using Assessment5.Entities;
using Assessment5.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace Assessment5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PomasterController : ControllerBase
    {
        private readonly IPomasterRepository _pomasterRepository;

        public PomasterController(IPomasterRepository pomasterRepository)
        {
            _pomasterRepository = pomasterRepository;
        }

        [HttpGet, Route("GetAllPomaster")]
        public async Task<IActionResult> GetAllPoma()
        {
            var pomasters= await _pomasterRepository.GetAll();
            return Ok(pomasters);
        }

        [HttpGet,Route("GetPomaster/{pono}")]
        public async Task<IActionResult> GetByPonoCode(string pono)
        {
            var pomaster = await _pomasterRepository.GetByPONO(pono);
            if(pomaster == null)
            {
                return NotFound("Pomaster not found");
            }
            return Ok(pomaster);
        }

        [HttpPost,Route("AddPomaster")]
        public async Task<IActionResult> AddPomaster(PomasterDTO pomasterDTO)
        {
            var pomaster = new Pomaster
            {
                pono = pomasterDTO.pono,
                ITCODE = pomasterDTO.ITCODE,
                SuplNo = pomasterDTO.SuplNo,
                date = pomasterDTO.Date,
                Quantity = pomasterDTO.Quantity
            };
            await _pomasterRepository.Add(pomaster);
            return Ok(pomaster);
        }
        [HttpPut,Route("UpdatePomaster")]
        public async Task<IActionResult> UpdatePomaster(PomasterDTO pomasterDTO)
        {
            var pomaster = new Pomaster
            {
                pono = pomasterDTO.pono,
                ITCODE = pomasterDTO.ITCODE,
                SuplNo = pomasterDTO.SuplNo,
                date = pomasterDTO.Date,
                Quantity = pomasterDTO.Quantity
            };
            await _pomasterRepository.Update(pomaster);
            return Ok(pomaster);
        }
       

        [HttpDelete,Route("DeletePomaster/{pono}")]
        public async Task<IActionResult> DeletePomaster(string pono)
        {
            await _pomasterRepository.Delete(pono);
            return Ok("Item successfully Deleted");
        }
    }
}
